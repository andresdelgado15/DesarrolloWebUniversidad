<!-- ********************************************************************** -->
<!-- ********************************************************************** -->
<!-- ********************************************************************** -->
<?php include "LectorPropiedades.php"?>
<?php
  session_start();
  $lectorPropiedades = new lectorPropiedades();
  $arregloPropiedades = $lectorPropiedades->leerPropiedadesSistema("propiedades.ini");
  $_SESSION["propiedades"] = $arregloPropiedades;
?>
<!-- ********************************************************************** -->
<!-- ********************************************************************** -->
<!-- ********************************************************************** -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <!-- ***************************************************** -->
  <!-- ***************************************************** -->
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta charset="UTF-8"/>
  <title>Acceso a Bases de Datos con PHP y MYSQL</title>
  <link rel="stylesheet" type="text/css" href="estilos/estilosAppBD.css"/>
  <script language="JavaScript" type="text/JavaScript" src="scripts/validacionesJS.js"></script>
  <!-- ***************************************************** -->
  <!-- ***************************************************** -->
</head>
<!-- *********************************************************** -->
<!-- *********************************************************** -->
<!-- *********************************************************** -->
<body class="oneColFixCtrHdr">
<div id="container">
  <div id="header">
    <h1><p align="center"><img src="imagenes/logoEAN.png" alt="Universidad EAN" longdesc="http://www.ean.edu.co" /></p></h1>
  <!-- end #header --></div>
  <div id="mainContent">
<h1>EAN University - Web Development</h1>
<p><strong>Presentado por: Andres Delgado y Diego Moreno<?php echo date("Y"); ?></strong></p>
    <center>
    <h2>ACCESO A DATOS DE MYSQL CON PHP</h2>
  </center>
    <p>
    	<center>
    	<table id="tabla" cellpadding="0" cellspacing="0" border="1">
      <tr>
              <td>ElIMINAR EMPLEADO</td>
              <td>
                  <a href="ConsultaEmpleadoEliminacion.php">Eliminar Empleado</a>
              </td>
          </tr>
    		  <tr>
    		  	  <td>REGISTRO DE EMPLEADOS</td>
    		  	  <td>
                  <a href="RegistroEmpleados.php">Registrar Nuevo Empleado</a>
    		  	  </td>
    		  </tr>
    		  <tr>
    		  	  <td>REGISTRO DE PRODUCTOS:</td>
    		  	  <td>
                  <a href="RegistroProductos.php">Registrar Nuevo Producto</a>
    		  	  </td>
    		  </tr>
    		  <tr>
    		  	  <td>CONSULTA DE EMPLEADOS</td>
    		  	  <td>
                  <a href="ConsultaEmpleados.php">Listas Empleados</a>
    		  	  </td>
    		  </tr>
          <tr>
              <td>CONSULTA DE PRODUCTOS</td>
              <td>
                  <a href="ConsultaProductos.php">Listas Productos</a>
              </td>
          </tr>
          
   		</table>
   	</center>
    </p>
    <br/>
    <br/>
	<!-- end #mainContent --></div>
  <div id="footer">
    <p><b><?php echo date("Y"); ?></b></p>
  <!-- end #footer --></div>
<!-- end #container --></div>
</body>
<!-- *********************************************************** -->
<!-- *********************************************************** -->
<!-- *********************************************************** -->
</html>
