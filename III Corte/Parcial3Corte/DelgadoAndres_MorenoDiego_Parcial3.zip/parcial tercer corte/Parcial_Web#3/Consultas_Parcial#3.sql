-- entrega del Primer punto del parcial
-- version # 1
-- Desarrollo Web
-- Fecha de Entrega: 2 de Noviembre 2018
-- parte # 1
--Presentado por: Edgar Andres Delgado  y Diego Moreno


-- 1. Mostrar el nombre, apellido, fecha de contratación, fecha de orden de compra y nombre de los libros, venidos por la empleada Aria Cruz

select 
fname as "Nombre empleado", 
lname as "Apellido Empleado", 
hire_date as "Fecha de contratación", 
ord_date as "Fecha de orden de compra", 
title as "Nombre del libro vendido"
from employee
inner join publishers on employee.pub_id = publishers.pub_id inner join titles on publishers.pub_id = titles.pub_id inner join sales on titles.title_id = sales.title_id
where fname = "aria";


-- 2. Mostrar el valor del descuento, el valor del descuento aplicado sobre el precio y el nombre de libro de todos los libros cuyo 
--    precio haya sido menor a 5 dólares o que hubiesen sido vendidos desde el 1 de febrero


select 
discount as "descuento aplicado", 
(price-discount) as "descuento sobre el producto", 
title as "libro sobre el que se aplicó el descuento"
from titles
inner join sales on titles.title_id = sales.title_id inner join stores on sales.stor_id = stores.stor_id inner join discounts on stores.stor_id = discounts.stor_id
where ord_date > '1992-02-01';



-- 3. Haga un resumen de la cantidad de libros existentes por cada categoría (popular_comp, mod_cook, trad_cook, business y psychology) y
--    organice el resumen de forma descendente (de la mayor cantidad de libros por categoría a la menor).

select 
`type` as 'categoria del Libro', 
count(`type`) as total 
from titles 
group by `type` 
order by total desc;




-- 4. Mostrar el listado de los libros que incluya el código del libro, el nombre del libro vendido, la categoría a la que pertenece,
--  el nombre de su editorial, la ciudad de la editorial que hayan sido vendidos por los empleados con cargo de Administrador de Mercadeo (Marketing Manager)


SELECT 
title_id as "Código del libros", 
job_desc as "Administrador de mercado", 
title as "nombre del libro", 
type as "Categoría", 
pub_name as "nombre de la editorial", 
city as "ciudad de la editorial"
from employee
inner join jobs on employee.job_id = jobs.job_id inner join publishers on employee.pub_id = publishers.pub_id inner join titles on publishers.pub_id = titles.pub_id
where job_desc = "Marketing Manager" ;
