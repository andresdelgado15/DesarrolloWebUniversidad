$(document).ready(function() {
    $("#botonAceptar").click(function() {
        var valInicial = parseInt($("#valor1").val());
        var varFinal = parseInt($("#valor2").val());

        while(valInicial <= varFinal){
            var x = (2*valInicial)/5;
            var y = Math.pow(valInicial,3)+1/3*(valInicial*Math.sqrt(valInicial));
            var z = 1/2 * (valInicial) + Math.sqrt(Math.log10(valInicial+1/ valInicial));

            generarTablaResultados(valInicial,x,y,z);
            
            valInicial++;
        }
    });

    function generarTablaResultados(a,x,y,z) {
 
    $(".tablaResultados").find('tr:nth-child(1)').append('<td>'+a+'</td>)');
    $(".tablaResultados").find('tr:nth-child(2)').append('<td>'+x+'</td>)');
    $(".tablaResultados").find('tr:nth-child(3)').append('<td>'+y+'</td>)');
    $(".tablaResultados").find('tr:nth-child(4)').append('<td>'+z+'</td>)');                
        
    }
});