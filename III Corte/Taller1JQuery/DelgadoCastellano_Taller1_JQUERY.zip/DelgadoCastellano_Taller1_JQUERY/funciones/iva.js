$(document).ready(function() {

    $(".resultado").hide();

    $("button").click(function() {

        var precio = parseInt($("#valorIva").val());
        var iva = 0.16;
        var descuento = [0.02, 0.06];

        iva = calcular(precio, iva);

        if (iva > 999 && iva < 2001) {
            descuento[1] = calcular(iva, descuento[0]);
            $(".iva").text(iva);
            iva -= calcular(iva, descuento[0]);
            $(".descuento").text(descuento[1])
            precio += iva;
            $(".total").text(precio);
            $(".resultado").show();
        } else if (iva > 2000 && iva < 5001) {
            descuento[0] = calcular(iva, descuento[1]);
            $(".iva").text(iva);
            iva -= calcular(iva, descuento[1]);
            $(".descuento").text(descuento[0]);
            precio += iva;
            console.log(precio);
            $(".total").text(precio);
            $(".resultado").show();
        } else if (precio > 5000) {
            descuento[0] = calcular(iva,descuento[1]);
            $(".iva").text(iva);
            iva -= calcular(iva, descuento[1]);
            $(".descuento").text(descuento[0]);
            precio += iva;
            console.log(precio);
            $(".total").text(precio);
            $(".resultado").show();
        }
        //No es mayor que 5000 o su iva no es mayor a 1000 COP.
        else {
            $(".iva").text(iva);
            precio +=iva;
            $(".total").text(precio);
            $(".resultado").show();  
        }
    });
    function calcular(a, b) {
        return a * b;
    }
});