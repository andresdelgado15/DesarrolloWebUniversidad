$(document).ready(function(){
    $("button").click(function(){
        var salario = parseInt($("#salario").val());
        var recargoDiurno = 0.1;
        var recargoNocturno = 0.2;
        var salarioCalculado = 0;
        var salud = 0.15;
        var pensiones = 0.145;
        var nivel = [ 0.0125, 0.0225, 0.0325, 0.0425, 0.0525];
        var resultadoNivel = 0;

        if($("#opcion1").is(":checked")){
            salario += calcular(salario,recargoDiurno);
            salarioCalculado = salario;
            salud = calcular(salarioCalculado, salud);
            pensiones = calcular(salarioCalculado, pensiones);
            if($("#riesgo1").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[0]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo2").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[1]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo3").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[2]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo4").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[3]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo5").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[4]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }
            else{
                alert("seleccione un nivel de riesgo");
            }
        }else if($("#opcion2").is(":checked")){
            salario += calcular(salario,recargoNocturno);
            salarioCalculado = salario;
            salud = calcular(salarioCalculado, salud);
            pensiones = calcular(salarioCalculado, pensiones);
            if($("#riesgo1").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[0]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo2").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[1]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo3").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[2]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo4").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[3]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo5").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[4]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }
            else{
                alert("seleccione un nivel de riesgo");
            }
        }else if($("#opcion3").is(":checked")){
            salarioCalculado = salario;
            salud = calcular(salarioCalculado, salud);
            pensiones = calcular(salarioCalculado, pensiones);
            if($("#riesgo1").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[0]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo2").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[1]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo3").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[2]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo4").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[3]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }else if($("#riesgo5").is(":checked")){
                resultadoNivel = calcular(salarioCalculado, nivel[4]);
                salario = salarioCalculado - (salud+pensiones+resultadoNivel);
                imprimir(salarioCalculado, salud, pensiones, salario);
            }
            else{
                alert("seleccione un nivel de riesgo");
            }
        }else{
            alert("Seleccione una opción.");
        }
    });
    function calcular(a,b){
        return a*b;
    }
    function imprimir(a,b,c,d){
        $(".salarioBruto").text(a);
        $(".Salud").text(b);
        $(".Pensiones").text(c);
        $(".salario").text(d);
    }
   });