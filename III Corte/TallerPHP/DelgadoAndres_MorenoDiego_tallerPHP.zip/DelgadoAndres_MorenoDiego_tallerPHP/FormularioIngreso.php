<?php include 'ClasesPHP.php';?>

<?php
   //Instanciación de los objetos de tipo clase ClasesPHP
   //Variable de tipo de la clase
   $ClasesPHP = new ClasesPHP;
   //Incializamos las variables del scriptlet
   $base =0;
   $altura =0;
   $resul_are=0;
   $resul_perimetro=0;

//******************************************************************* */
//******************************************************************* */
function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	//$data = htmlspecialchars($data);
	return $data;
  }

   
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$base = test_input($_POST["base"]);
	$altura = test_input($_POST["altura"]);
	//$resul_are = test_input($_POST["resul_are"]);
	//$resul_perimetro= test_input($_POST["resul_perimetro"]);
	

  }
  
 
//******************************************************************* */
  //******************************************************************* */
   //Usar el objeto para crear los resultados en las variables del scriptlet}
   $resul_are = $ClasesPHP->cal_area($base,$altura);
   $resul_perimetro = $ClasesPHP->cal_perimetro($base,$altura);
   

?>

<!--
	*********************************************************************************
	*********************************************************************************
	*********************************************************************************
-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Modelo 4</title>
<link rel="stylesheet" href="css/style.css"> 
</head>
<body class="oneColFixCtrHdr" >
	
<div class="navbar"> 
		<ul>
			<li>
				<a href="index.php" target="_blank">Calculo Salario</a>
			</li>
			<li>
				<a href="punto2.php" target="_blank">Calculo de Notas</a>
			</li>
			<li><a href="FormularioIngreso.php" target="_blank">Perimetro & Area</a></li>
			<li><a href="FormularioIngreso_punto4.php" target="_blank">Calcular A - B - C</a></li>
		</ul>
	</div>

<div id="container">
  <div id="header">
    <h1><p align="center"><img src="imagenes/logoEAN.jpg" width="129" height="124" alt="Universidad EAN" longdesc="http://www.ean.edu.co" /></p></h1>
  <!-- end #header --></div>
  <div id="mainContent">
<h1>EAN University - Web Development</h1>
<h3>Presentado por: Edgar Andres Delgado</h3>
<h3 style= "color: blue">Ejercicio Numero 3 - Calculo Area & Perimetro</h3>


 <!--Comienza el formulario de php -->
	<h2>Formulario para Calcular Area y Perimetro de Un Rectanguloa</h2>
	<br><br>
<form method="post" action="FormularioRespuesta.php">  
  Ingrese la <b>Base: </b>   <input type="text" name="base">
  <br><br>
  Ingrese la <b>Altura: </b>  <input type="text" name="altura">
  <br><br>
  

  <br>
  <input type="submit" name="submit" value="Submit" id="envio" src="FormularioRespuesta.php">  
  <input type="reset" value="Borrar formulario" id="envio">
</form>
</form>

 <!--termina el formulario php -->

	   <br>
	<!-- creamos la tabla de resultados  	  
	   <h3>Resultados Ares & Perimetro</h3>

	   <p><center>
    	<table id="tabla" cellpadding="0" cellspacing="0" border="1">
		<tr>
    	<td >longitud Base:</td>
    	<td > <?=$base?> </td>
    		  </tr>
			  <tr>
    	<td >Longitud Altura</td>
    	<td > <?=$altura?> </td>
			  </tr>
			  <tr>
				  <td>El resultado del <b>Area</b> es: </td>
				  <td><?=$resul_are?> m<sup>2</sup>.</td>
			  </tr>
			  <tr>
				  <td>El resultado del <b>Perimetro</b> es: </td>
				  <td><?=$resul_perimetro?> metros.</td>
				 
			  </tr>
			 
    	
			  </table>
</p>
	   </center> -->
	   

    
	<!-- end #mainContent --></div>
  <div id="footer">
    <p>Footer</p>
  <!-- end #footer --></div>
<!-- end #container --></div>
</body>
</html>
