<?php
/****************************************************************/
/****************************************************************/

class ClasesPHP
{
	//Atributos o variables de instancia
	
	var $base;
	var $altura;
	var $resul_are;
	var $resul_perimetro;


	//Encapsulamiento
	//************************************************************** */
	//************************************************************** */
	// base

	function getBase()
	{
		return ($this->base);
	}

	function setBase($base)
	{
		$this->base = $base;
	}

	//************************************************************** */
	// altura
	
	function getAltura()
	{
		return ($this->altura);
	}

	function setAltura($altura)
	{
		$this->altura = $altura;
	}

	
//************************************************************** */
//************************************************************** */

//Métodos de lógica asociados al comportamiento de la clase


//Funcion para calcular area

function cal_area ($base,$altura)
{
	$this->resul_area = $base * $altura;
	return ($this->resul_area);
}


//Funcion para calcular perimetro

function cal_perimetro ($base,$altura)
{
	$this->resul_perimetro = ($base + $altura) * 2;
	return ($this->resul_perimetro);
}




	/****************************************************************/
	/****************************************************************/
}//Fin de la clase
/****************************************************************/
/****************************************************************/
/****************************************************************/
?>