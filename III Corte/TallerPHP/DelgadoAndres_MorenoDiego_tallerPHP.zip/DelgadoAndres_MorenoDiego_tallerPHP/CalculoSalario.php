<?php
/****************************************************************/
/****************************************************************/

class CalculoSalario
{
	//Atributos o variables de instancia
	
	var $nombre;
	var$apellido;
	var$numeroHora;
	var $valorHora;
	var $sueldoBruto;
	var $nivelRiesgo;
	var $riesgoProfesional;
	var $salud;
	var $pension;
	var$totalDescuento;
	var $sueldoNeto;

	//Encapsulamiento
	//************************************************************** */
	//************************************************************** */
	// nombre

	function getNombre()
	{
		return ($this->nombre);
	}

	function setNombre($nombre)
	{
		$this->nombre = $nombre;
	}

	//************************************************************** */
	// apellido
	
	function getApellido()
	{
		return ($this->apellido);
	}

	function setApellido($apellido)
	{
		$this->apellido = $apellido;
	}

	//************************************************************** */
     // numeroHora
	
	function getnumeroHora()
	{
		return ($this->numeroHora);
	}

	function setnumeroHora($numeroHora)
	{
		$this->numeroHora = $numeroHora;
	}

    //************************************************************** */
     // valorHora
	
	 function getvalorHora()
	 {
		 return ($this->valorHora);
	 }
 
	 function setvalorHora($valorHora)
	 {
		 $this->valorHora = $valorHora;
	 }


	//************************************************************** */
     // sueldoBruto

	 function getsueldoBruto()
	 {
		 return ($this->sueldoBruto);
	 }
 
	 function setsueldoBruto($sueldoBruto)
	 {
		 $this->sueldoBruto = $sueldoBruto;
	 }


	 //************************************************************** */
	 // salud
	 function getsalud()
	 {
		 return ($this->salud);
	 }
 
	 function setsalud($salud)
	 {
		 $this->salud = $salud;
	 }
	 

	  //************************************************************** */
	 // pension
	 function getpension()
	 {
		 return ($this->pension);
	 }
 
	 function setpension($pension)
	 {
		 $this->pension = $pension;
	 }


	   //************************************************************** */
	 // Riesgo Profesional
	 function getRiesgoProfesional()
	 {
		 return ($this->riesgoProfesional);
	 }
 
	 function setRiesgoProfesional($riesgoProfesional)
	 {
		 $this->riesgoProfesional = $riesgoProfesional;
	 }

	    //************************************************************** */
	 // totalDescuento
	 function gettotalDescuento()
	 {
		 return ($this->totalDescuento);
	 }
 
	 function settotalDescuento($totalDescuento)
	 {
		 $this->totalDescuento = $totalDescuento;
	 }


	     //************************************************************** */
	 // sueldoNeto
	 function getsueldoNeto()
	 {
		 return ($this->sueldoNeto);
	 }
 
	 function setsueldoNeto($sueldoNeto)
	 {
		 $this->sueldoNeto = $sueldoNeto;
	 }

    //************************************************************** */
    //************************************************************** */
	   
//Métodos de lógica asociados al comportamiento de la clase
// Funcion de test para el formulario


 //Funcion De Sueldo Bruto

function suel_bruto ($numeroHora,$valorHora)
{
	$this->sueldoBruto = $numeroHora * $valorHora;
	return ($this->sueldoBruto);
}

//Funcion de Nivel de Riesgo

function riesgo ($nivelRiesgo,$sueldoBruto)
{
if($nivelRiesgo==1){
		$riesgoProfesional= $sueldoBruto*0.05;
	}
	else if($nivelRiesgo==2){
		$riesgoProfesional= $sueldoBruto*0.14;
	}

	else if($nivelRiesgo==3){
		$riesgoProfesional= $sueldoBruto*0.16;
	}
	
	elseif($nivelRiesgo==4){
		$riesgoProfesional= $sueldoBruto*0.33;
	}
	
 	return ($riesgoProfesional);
 }

//Funcion de salud

function sal ($sueldoBruto)
{
	$salud=$sueldoBruto*0.145;
	
	return $salud;
}


//Funcion de pension

function pen ($sueldoBruto)
{
	$pension=$sueldoBruto*0.126;
	
	return $pension;
}

//Funcion de Descuento

function descuento ($salud,$pension,$riesgoProfesional)
{
	$totalDescuento= $salud + $pension + $riesgoProfesional;
	
	return $totalDescuento;
}


//Funcion de Neto
function neto ($sueldoBruto,$totalDescuento)
{
	$sueldoNeto = $sueldoBruto - $totalDescuento;
	return $sueldoNeto;
}

	
	/****************************************************************/
	/****************************************************************/
}//Fin de la clase
/****************************************************************/
/****************************************************************/
/****************************************************************/
?>