<?php include 'ClasesPHP_punto4.php';?>

<?php
   //Instanciación de los objetos de tipo clase ClasesPHP_punto4
   //Variable de tipo de la clase
   $ClasesPHP_punto4 = new ClasesPHP_punto4;
   //Incializamos las variables del scriptlet
   $x1 =0;
	 $y1 =0;
	 $x2=0;
	 $y2=0;
	 $m=0;
	 $a=0;
   $b=0;
	 $c=0;
//******************************************************************* */
//******************************************************************* */
function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	//$data = htmlspecialchars($data);
	return $data;
  }

   
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$x1 = test_input($_POST["x1"]);
	$y1 = test_input($_POST["y1"]);
	$x2 = test_input($_POST["x2"]);
	$y2 = test_input($_POST["y2"]);
	//$altura = test_input($_POST["altura"]);
	//$resul_are = test_input($_POST["resul_are"]);
	//$resul_perimetro= test_input($_POST["resul_perimetro"]);
	

  }
  
 
//******************************************************************* */
  //******************************************************************* */
   //Usar el objeto para crear los resultados en las variables del scriptlet}
	$m = $ClasesPHP_punto4->pendiente($x1,$y1,$x2,$y2);
	$a = $ClasesPHP_punto4->valor_a($m);
	$c = $ClasesPHP_punto4->valor_c($x2,$y2,$m);
	$b = $ClasesPHP_punto4->valor_b($x2,$c,$m);

   

?>

<!--
	*********************************************************************************
	*********************************************************************************
	*********************************************************************************
-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Modelo 4</title>
<link rel="stylesheet" href="css/style.css"> 
</head>
<body class="oneColFixCtrHdr" >
	
	<div class="navbar"> 
		<ul>
			<li>
				<a href="index.php" target="_blank">Calculo Salario</a>
			</li>
			<li>
				<a href="punto2.php" target="_blank">Calculo de Notas</a>
			</li>
			<li><a href="FormularioIngreso.php" target="_blank">Perimetro & Area</a></li>
			<li><a href="FormularioIngreso_punto4.php" target="_blank">Calcular A - B - C</a></li>
		</ul>
	</div>

<div id="container">
  <div id="header">
    <h1><p align="center"><img src="imagenes/logoEAN.jpg" width="129" height="124" alt="Universidad EAN" longdesc="http://www.ean.edu.co" /></p></h1>
  <!-- end #header --></div>
  <div id="mainContent">
<h1>EAN University - Web Development</h1>
<h3>Presentado por: Edgar Andres Delgado</h3>
<h3 style= "color: blue">Ejercicio Numero 4 - Calcular Valores De A , B, C.</h3>


 <!--Comienza el formulario de php -->
	<h2>Algoritmo Para Calcular Valores de una Recta</h2>
	<br><br>
<form method="post" action="FormularioRespuesta_punto4.php">  
  Ingrese el valor de <b>X1</b>  <input type="text" name="x1">
  <br><br>
  Ingrese el valor de <b>Y1</b>  <input type="text" name="y1">
	<br><br>
	Ingrese el valor de <b>X2</b>  <input type="text" name="x2">
  <br><br>
  Ingrese el valor de <b>Y2</b>  <input type="text" name="y2">
  <br><br>
  

  <br>
  <input type="submit" name="submit" value="Submit" id="envio" src="FormularioRespuesta_punto4.php">  
  <input type="reset" value="Borrar formulario" id="envio">
</form>
</form>

 <!--termina el formulario php -->

	   <br>
	<!-- creamos la tabla de resultados  	  
	   <h3>Resultados Ares & Perimetro</h3>

	   <p><center>
    	<table id="tabla" cellpadding="0" cellspacing="0" border="1">
		<tr>
    	<td >longitud Base:</td>
    	<td > <?=$base?> </td>
    		  </tr>
			  <tr>
    	<td >Longitud Altura</td>
    	<td > <?=$altura?> </td>
			  </tr>
			  <tr>
				  <td>El resultado del <b>Area</b> es: </td>
				  <td><?=$resul_are?> m<sup>2</sup>.</td>
			  </tr>
			  <tr>
				  <td>El resultado del <b>Perimetro</b> es: </td>
				  <td><?=$resul_perimetro?> metros.</td>
				 
			  </tr>
			 
    	
			  </table>
</p>
	   </center> -->
	   

    
	<!-- end #mainContent --></div>
  <div id="footer">
    <p>Footer</p>
  <!-- end #footer --></div>
<!-- end #container --></div>
</body>
</html>
