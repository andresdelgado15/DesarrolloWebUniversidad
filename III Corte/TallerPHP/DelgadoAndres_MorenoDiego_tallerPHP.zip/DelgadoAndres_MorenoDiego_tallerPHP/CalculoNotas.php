<?php
/****************************************************************/
/****************************************************************/

class CalculoNotas
{
	//Atributos o variables de instancia
	
	var $nombre;
	var $apellido;
	var $nota1;
	var $resul_nota1;
	var $nota2;
	var $resul_nota2;
	var $nota3;
	var $resul_nota3;
	var $definitiva;

	//Encapsulamiento
	//************************************************************** */
	//************************************************************** */
	// nombre

	function getNombre()
	{
		return ($this->nombre);
	}

	function setNombre($nombre)
	{
		$this->nombre = $nombre;
	}

	//************************************************************** */
	// apellido
	
	function getApellido()
	{
		return ($this->apellido);
	}

	function setApellido($apellido)
	{
		$this->apellido = $apellido;
	}

	//************************************************************** */
    // nota1
	function getNota1()
	{
		return ($this->nota1);
	}

	function setnota1($nota1)
	{
		$this->nota1 = $nota1;
	}

//************************************************************** */
    // nota2
	function getNota2()
	{
		return ($this->nota2);
	}

	function setnota2($nota2)
	{
		$this->nota2 = $nota2;
	}

//************************************************************** */
    // nota3
	function getNota3()
	{
		return ($this->nota3);
	}

	function setnota3($nota3)
	{
		$this->nota3 = $nota3;
	}

	//************************************************************** */
    // definitiva
	function getDefinitiva()
	{
		return ($this->definitiva);
	}

	function setdefinitiva($definitiva)
	{
		$this->definitiva = $definitiva;
	}


//************************************************************** */
//************************************************************** */

//Métodos de lógica asociados al comportamiento de la clase


//Funcion Nota # 1

function primer_corte ($nota1)
{
	$this->resul_nota1 = $nota1 * 0.3;
	return ($this->resul_nota1);
}


//Funcion Nota # 2

function segundo_corte ($nota2)
{
	$this->resul_nota2 = $nota2 * 0.3;
	return ($this->resul_nota2);
}

//Funcion Nota # 3

function tercer_corte ($nota3)
{
	$this->resul_nota3 = $nota3 * 0.4;
	return ($this->resul_nota3);
}


//Funcion Definitiva

function def ($resul_nota1,$resul_nota2,$resul_nota3)
{
	$definitiva = $resul_nota1 + $resul_nota2 + $resul_nota3;
	return ($definitiva);
}


	/****************************************************************/
	/****************************************************************/
}//Fin de la clase
/****************************************************************/
/****************************************************************/
/****************************************************************/
?>