<?php include 'CalculoSalario.php';?>
<?php
   //Instanciación de los objetos de tipo clase CalculoSalario
   //Variable de tipo de la clase
   $CalculoSalario = new CalculoSalario;
   //Incializamos las variables del scriptlet

   $nombre=0;
   $apellido=0;
   $numeroHora =0;
   $valorHora =0;
   $sueldoBruto=0;
   $nivelRiesgo=0;
   $salud=0;
   $pension=0;
   $riesgoProfesional=0;
   $totalDescuento=0;
   $sueldoNeto=0;
   
//******************************************************************* */
//******************************************************************* */
function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
  }

   
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$nombre = test_input($_POST["nombre"]);
	$apellido = test_input($_POST["apellido"]);
	$numeroHora = test_input($_POST["numeroHora"]);
	$valorHora = test_input($_POST["valorHora"]);
	$nivelRiesgo = test_input($_POST["nivelRiesgo"]);
	
  }
  
 
//******************************************************************* */
  //******************************************************************* */
   //Usar el objeto para crear los resultados en las variables del scriptlet}

   $sueldoBruto = $CalculoSalario->suel_bruto($numeroHora,$valorHora);
   $riesgoProfesional = $CalculoSalario->riesgo($nivelRiesgo,$sueldoBruto);
   $salud = $CalculoSalario->sal($sueldoBruto);
   $pension = $CalculoSalario->pen($sueldoBruto);
   $totalDescuento = $CalculoSalario->descuento($salud,$pension,$riesgoProfesional);
   $sueldoNeto = $CalculoSalario->neto($sueldoBruto,$totalDescuento);
?>

<!--
	*********************************************************************************
	*********************************************************************************
	*********************************************************************************
-->



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Modelo 4</title>
<link rel="stylesheet" href="css/style.css"> 
</head>
<body class="oneColFixCtrHdr" >
<div class="navbar"> 
		<ul>
			<li>
				<a href="index.php" target="_blank">Calculo Salario</a>
			</li>
			<li>
				<a href="punto2.php" target="_blank">Calculo de Notas</a>
			</li>
			<li><a href="FormularioIngreso.php" target="_blank">Perimetro & Area</a></li>
			<li><a href="FormularioIngreso_punto4.php" target="_blank">Calcular A - B - C</a></li>
		</ul>
	</div>

<div id="container">
  <div id="header">
    <h1><p align="center"><img src="imagenes/logoEAN.jpg" width="129" height="124" alt="Universidad EAN" longdesc="http://www.ean.edu.co" /></p></h1>
  <!-- end #header --></div>
  <div id="mainContent">
<h1>EAN University - Web Development</h1>
<h3>Presentado por: Edgar Andres Delgado</h3>
<h3 style= "color: blue">Ejercicio Numero 1</h3>

	
 <!--Comienza el formulario de php -->
	<h2>Formulario Empleado</h2>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
  Nombre: <input type="text" name="nombre">
  <br><br>
  Apellido: <input type="text" name="apellido">
  <br><br>
  Numero de Horas: <input type="text" name="numeroHora">
  <br><br>
  Valor Hora: <input type="text" name="valorHora">
  <br><br>
  Ingrese el Nivel de Riesgo de 1 a 4: <input type="text" name="nivelRiesgo">
  <br><br>

  <br><br>
  <input type="submit" name="submit" value="Submit" id="envio">  
  <input type="reset" value="Borrar formulario" id="envio">
</form>

 <!--termina el formulario php -->


<!--
	*********************************************************************************
	*********************************************************************************
	*********************************************************************************
-->
<p><center>
    	<table id="tabla" cellpadding="0" cellspacing="0" border="1">
		<tr>
    	<td>Nombre:</td>
    	<td> <?=$nombre?> </td>
    		  </tr>
			  <tr>
    	<td>Apellido:</td>
    	<td> <?=$apellido?> </td>
			  </tr>
			  <tr>
    	<td>Numero de Horas:</td>
    	<td> $ <?=$numeroHora?> </td>
    		  </tr>
	<tr>
    	<td>Valor x Hora:</td>
    	<td> $ <?=$valorHora?> </td>
			  </tr>
			  
			  <tr>
    	<td>Nivel de riesgo:</td>
    	<td> <?=$nivelRiesgo?> </td>
    		  </tr>
	</table>
</p>
	   </center>
	   <br>
	   <br>

	  
	   <h3>Resultados</h3>
<!-- creamos la tabla de resultados-->
	   <p><center>
    	<table id="tabla" cellpadding="0" cellspacing="0" border="1">
		<tr>
    	<td>Sueldo Bruto:</td>
    	<td> $ <?=$sueldoBruto?> </td>
			  </tr>
			  <tr>
    	<td>Salud:</td>
    	<td> $ <?=$salud?> </td>
			  </tr>
			  <tr>
    	<td>Pension:</td>
    	<td> $ <?=$pension?> </td>
			  </tr>
			  
			  <tr>
    	<td>Riesgos Profesionales:</td>
    	<td> $ <?=$riesgoProfesional?> </td>
			  </tr>
			  
			  <td>Total Descuento:</td>
    	<td> $ <?=$totalDescuento?> </td>
			  </tr>
			  
			  <td><b>Sueldo Neto</b></td>
    	<td> $ <?=$sueldoNeto?> </td>
    		  </tr>
			  </table>
</p>
	   </center>
	   

    
	<!-- end #mainContent --></div>
  <div id="footer">
    <p>Footer</p>
  <!-- end #footer --></div>
<!-- end #container --></div>
</body>
</html>
