<?php
/****************************************************************/
/****************************************************************/

class ClasesPHP_punto4
{
	//Atributos o variables de instancia
	
	var $x1;
	var $y1;
	var $x2;
	var $y2;
	var $m;
	var $a;
	var $b;
	var $c;
	


	//Encapsulamiento
	//************************************************************** */
	//************************************************************** */
	// x1

	function getX1()
	{
		return ($this->x1);
	}

	function setX1($x1)
	{
		$this->x1 = $x1;
	}

	//************************************************************** */
	// x2

	function getX2()
	{
		return ($this->x2);
	}

	function setX2($x2)
	{
		$this->x2 = $x2;
	}


	//************************************************************** */
	// y1

	function getY1()
	{
		return ($this->y1);
	}

	function setY1($y1)
	{
		$this->y1 = $y1;
	}

	//************************************************************** */
	// y2

	function getY2()
	{
		return ($this->y2);
	}

	function setY2($y2)
	{
		$this->y2 = $y2;
	}

		//************************************************************** */
	// m

	function getM()
	{
		return ($this->m);
	}

	function setM($m)
	{
		$this->m = $m;
	}
	
//************************************************************** */
//************************************************************** */

//Métodos de lógica asociados al comportamiento de la clase


//Funcion para calcular pendiente
//la pendiente es lo que acompaña a X

function pendiente ($x1,$y1,$x2,$y2)
{
	$this->m = ($y2-$y1) / ($x2 - $x1);
	return ($this->m);
}
// calculamos el valor de a
function valor_a ($m)
{
	$this->a = $m;
	return ($this->a);
}
// calculamos el valor de C
function Valor_c($x2,$y2,$m)
{
	$this->c= -($m * $x2) +$y2;
	return ($this->c);
}

// calculamos el valor de B
function valor_b($x2,$c,$m)
{
	//$this->b= (-$c-($a*$x2))/$y2;
	$this->b= ($m * $x2) +$c +$m;
	
	return ($this->b);
}



	/****************************************************************/
	/****************************************************************/
}//Fin de la clase
/****************************************************************/
/****************************************************************/
/****************************************************************/
?>